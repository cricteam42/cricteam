## cricket live scores platform - **criclive**

#### configuring database:
import the test db schema file `morasp5_criclive.sql` in *schema* directory to your **mysql server**.

then edit the file `DBCon.php` to enter credentials for db.

```
$con = mysqli_connect("localhost", "user", "pass", "morasp5_criclive", "3306");

```

then navigate to `localhost/criclive` .

![moraspirit logo](http://moraspirit.com/sites/default/files/msp_text_logo_300.png)  
baked with ♥♥ in UOM.
