<?php
	$conn = mysqli_connect("localhost","root","","morasp5_criclive");
?>